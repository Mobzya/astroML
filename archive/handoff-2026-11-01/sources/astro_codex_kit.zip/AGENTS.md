# AGENTS — AstroML microlensing / «Шаг в будущее»

Goal: defensible, reproducible scientific work by an individual student, not leaderboard chasing. Read `CODEX_MASTER_PROMPT_RU.md` for the full specification. Apply relevant repo skills in `.agents/skills/`.

Rules:
- Never fabricate data, sources, tool execution, metrics, p-values, charts, claims of novelty, approvals, or successful remote GPU jobs.
- Distinguish simulation, validation, locked test, independent external validation, and real telescope observations.
- Keep train/validation/test split by original physical source/event, never by individual sampled lightcurve points.
- Do not use test labels or privileged simulation parameters as inference input or for model selection.
- Start with tests and CPU smoke. Do not consume GPU before smoke passes. Check Kaggle quota and request approval for paid or unusually large jobs.
- Store run_id, git SHA, dataset checksum, configuration, seed, dependencies, GPU type, logs and output path.
- Credentials are private: do not place Kaggle tokens, Colab/Google credentials or API keys in code, logs or Git.
- Treat a physical lensing event and a black-hole detection as different scientific claims.
- Never claim project originality solely from combining PSPL and neural networks. Cite and benchmark closest studies.
- Prefer a finished scientific demonstration, manuscript and defense to gratuitous architectures and excessive model size.
- Ask the student to understand and verify decisions; document AI-assisted contributions transparently.

Update every turn: implemented / tested / measured / blocked / next. Do not attempt login, publish a repository, or spend external compute without owner's authorized setup.
